gdjs.MainCode = {};
gdjs.MainCode.GDCuteGirlObjects1= [];
gdjs.MainCode.GDCuteGirlObjects2= [];
gdjs.MainCode.GDCuteGirlObjects3= [];
gdjs.MainCode.GDBackgroundObjects1= [];
gdjs.MainCode.GDBackgroundObjects2= [];
gdjs.MainCode.GDBackgroundObjects3= [];
gdjs.MainCode.GDTextGirlObjects1= [];
gdjs.MainCode.GDTextGirlObjects2= [];
gdjs.MainCode.GDTextGirlObjects3= [];
gdjs.MainCode.GDButtonPlayObjects1= [];
gdjs.MainCode.GDButtonPlayObjects2= [];
gdjs.MainCode.GDButtonPlayObjects3= [];
gdjs.MainCode.GDTextInputValueObjects1= [];
gdjs.MainCode.GDTextInputValueObjects2= [];
gdjs.MainCode.GDTextInputValueObjects3= [];

gdjs.MainCode.conditionTrue_0 = {val:false};
gdjs.MainCode.condition0IsTrue_0 = {val:false};
gdjs.MainCode.condition1IsTrue_0 = {val:false};
gdjs.MainCode.condition2IsTrue_0 = {val:false};
gdjs.MainCode.condition3IsTrue_0 = {val:false};
gdjs.MainCode.condition4IsTrue_0 = {val:false};
gdjs.MainCode.conditionTrue_1 = {val:false};
gdjs.MainCode.condition0IsTrue_1 = {val:false};
gdjs.MainCode.condition1IsTrue_1 = {val:false};
gdjs.MainCode.condition2IsTrue_1 = {val:false};
gdjs.MainCode.condition3IsTrue_1 = {val:false};
gdjs.MainCode.condition4IsTrue_1 = {val:false};


gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDButtonPlayObjects1Objects = Hashtable.newFrom({"ButtonPlay": gdjs.MainCode.GDButtonPlayObjects1});
gdjs.MainCode.asyncCallback7609964 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GameOver", false);
}}
gdjs.MainCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.MainCode.asyncCallback7609964(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainCode.eventsList1 = function(runtimeScene) {

{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) == 0;
}if (gdjs.MainCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GameOver", false);
}}

}


{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) < gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1));
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("TextGirl"), gdjs.MainCode.GDTextGirlObjects2);
{for(var i = 0, len = gdjs.MainCode.GDTextGirlObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDTextGirlObjects2[i].setBBText("Que pena, você errou!!!!! O número que estou pensando é menor do que " + gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(1)));
}
}}

}


{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1));
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("TextGirl"), gdjs.MainCode.GDTextGirlObjects1);
{for(var i = 0, len = gdjs.MainCode.GDTextGirlObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDTextGirlObjects1[i].setBBText("Que pena, você errou!!!!! O número que estou pensando é maior do que " + gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(1)));
}
}}

}


};gdjs.MainCode.eventsList2 = function(runtimeScene) {

{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1));
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("TextGirl"), gdjs.MainCode.GDTextGirlObjects2);
{for(var i = 0, len = gdjs.MainCode.GDTextGirlObjects2.length ;i < len;++i) {
    gdjs.MainCode.GDTextGirlObjects2[i].setBBText("Parabens, você acertou!!!!!!");
}
}
{ //Subevents
gdjs.MainCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) != gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1));
}if (gdjs.MainCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(1).sub(1);
}
{ //Subevents
gdjs.MainCode.eventsList1(runtimeScene);} //End of subevents
}

}


};gdjs.MainCode.eventsList3 = function(runtimeScene) {

{


gdjs.MainCode.condition0IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MainCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("TextGirl"), gdjs.MainCode.GDTextGirlObjects1);
{runtimeScene.getVariables().getFromIndex(0).setNumber(gdjs.randomInRange(1, 10));
}{for(var i = 0, len = gdjs.MainCode.GDTextGirlObjects1.length ;i < len;++i) {
    gdjs.MainCode.GDTextGirlObjects1[i].setBBText("Olá " + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) + ", estou pensando em um número entre o número 1 e o número 10. Que tal tentar adivinhar?");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ButtonPlay"), gdjs.MainCode.GDButtonPlayObjects1);
gdjs.copyArray(runtimeScene.getObjects("TextInputValue"), gdjs.MainCode.GDTextInputValueObjects1);

gdjs.MainCode.condition0IsTrue_0.val = false;
gdjs.MainCode.condition1IsTrue_0.val = false;
gdjs.MainCode.condition2IsTrue_0.val = false;
gdjs.MainCode.condition3IsTrue_0.val = false;
{
gdjs.MainCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainCode.mapOfGDgdjs_46MainCode_46GDButtonPlayObjects1Objects, runtimeScene, true, false);
}if ( gdjs.MainCode.condition0IsTrue_0.val ) {
{
gdjs.MainCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.MainCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainCode.GDTextInputValueObjects1.length;i<l;++i) {
    if ( gdjs.MainCode.GDTextInputValueObjects1[i].getString() != "" ) {
        gdjs.MainCode.condition2IsTrue_0.val = true;
        gdjs.MainCode.GDTextInputValueObjects1[k] = gdjs.MainCode.GDTextInputValueObjects1[i];
        ++k;
    }
}
gdjs.MainCode.GDTextInputValueObjects1.length = k;}if ( gdjs.MainCode.condition2IsTrue_0.val ) {
{
{gdjs.MainCode.conditionTrue_1 = gdjs.MainCode.condition3IsTrue_0;
gdjs.MainCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8549372);
}
}}
}
}
if (gdjs.MainCode.condition3IsTrue_0.val) {
/* Reuse gdjs.MainCode.GDTextInputValueObjects1 */
{runtimeScene.getVariables().getFromIndex(1).setNumber(gdjs.evtTools.common.toNumber((( gdjs.MainCode.GDTextInputValueObjects1.length === 0 ) ? "" :gdjs.MainCode.GDTextInputValueObjects1[0].getString())));
}
{ //Subevents
gdjs.MainCode.eventsList2(runtimeScene);} //End of subevents
}

}


{


{
}

}


};

gdjs.MainCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.MainCode.GDCuteGirlObjects1.length = 0;
gdjs.MainCode.GDCuteGirlObjects2.length = 0;
gdjs.MainCode.GDCuteGirlObjects3.length = 0;
gdjs.MainCode.GDBackgroundObjects1.length = 0;
gdjs.MainCode.GDBackgroundObjects2.length = 0;
gdjs.MainCode.GDBackgroundObjects3.length = 0;
gdjs.MainCode.GDTextGirlObjects1.length = 0;
gdjs.MainCode.GDTextGirlObjects2.length = 0;
gdjs.MainCode.GDTextGirlObjects3.length = 0;
gdjs.MainCode.GDButtonPlayObjects1.length = 0;
gdjs.MainCode.GDButtonPlayObjects2.length = 0;
gdjs.MainCode.GDButtonPlayObjects3.length = 0;
gdjs.MainCode.GDTextInputValueObjects1.length = 0;
gdjs.MainCode.GDTextInputValueObjects2.length = 0;
gdjs.MainCode.GDTextInputValueObjects3.length = 0;

gdjs.MainCode.eventsList3(runtimeScene);
return;

}

gdjs['MainCode'] = gdjs.MainCode;
