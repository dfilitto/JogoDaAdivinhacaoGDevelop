gdjs.MenuCode = {};
gdjs.MenuCode.GDCuteGirlObjects1= [];
gdjs.MenuCode.GDCuteGirlObjects2= [];
gdjs.MenuCode.GDGameNameTextObjects1= [];
gdjs.MenuCode.GDGameNameTextObjects2= [];
gdjs.MenuCode.GDBlueBackgroundObjects1= [];
gdjs.MenuCode.GDBlueBackgroundObjects2= [];
gdjs.MenuCode.GDTextoNumeroTextObjects1= [];
gdjs.MenuCode.GDTextoNumeroTextObjects2= [];
gdjs.MenuCode.GDTextInputNameObjects1= [];
gdjs.MenuCode.GDTextInputNameObjects2= [];
gdjs.MenuCode.GDButtonPlayObjects1= [];
gdjs.MenuCode.GDButtonPlayObjects2= [];

gdjs.MenuCode.conditionTrue_0 = {val:false};
gdjs.MenuCode.condition0IsTrue_0 = {val:false};
gdjs.MenuCode.condition1IsTrue_0 = {val:false};
gdjs.MenuCode.condition2IsTrue_0 = {val:false};
gdjs.MenuCode.condition3IsTrue_0 = {val:false};


gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDButtonPlayObjects1Objects = Hashtable.newFrom({"ButtonPlay": gdjs.MenuCode.GDButtonPlayObjects1});
gdjs.MenuCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ButtonPlay"), gdjs.MenuCode.GDButtonPlayObjects1);
gdjs.copyArray(runtimeScene.getObjects("TextInputName"), gdjs.MenuCode.GDTextInputNameObjects1);

gdjs.MenuCode.condition0IsTrue_0.val = false;
gdjs.MenuCode.condition1IsTrue_0.val = false;
gdjs.MenuCode.condition2IsTrue_0.val = false;
{
gdjs.MenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDButtonPlayObjects1Objects, runtimeScene, true, false);
}if ( gdjs.MenuCode.condition0IsTrue_0.val ) {
{
gdjs.MenuCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.MenuCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MenuCode.GDTextInputNameObjects1.length;i<l;++i) {
    if ( gdjs.MenuCode.GDTextInputNameObjects1[i].getString() != "" ) {
        gdjs.MenuCode.condition2IsTrue_0.val = true;
        gdjs.MenuCode.GDTextInputNameObjects1[k] = gdjs.MenuCode.GDTextInputNameObjects1[i];
        ++k;
    }
}
gdjs.MenuCode.GDTextInputNameObjects1.length = k;}}
}
if (gdjs.MenuCode.condition2IsTrue_0.val) {
/* Reuse gdjs.MenuCode.GDTextInputNameObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(0).setString((( gdjs.MenuCode.GDTextInputNameObjects1.length === 0 ) ? "" :gdjs.MenuCode.GDTextInputNameObjects1[0].getString()));
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(3);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main", false);
}}

}


};

gdjs.MenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.MenuCode.GDCuteGirlObjects1.length = 0;
gdjs.MenuCode.GDCuteGirlObjects2.length = 0;
gdjs.MenuCode.GDGameNameTextObjects1.length = 0;
gdjs.MenuCode.GDGameNameTextObjects2.length = 0;
gdjs.MenuCode.GDBlueBackgroundObjects1.length = 0;
gdjs.MenuCode.GDBlueBackgroundObjects2.length = 0;
gdjs.MenuCode.GDTextoNumeroTextObjects1.length = 0;
gdjs.MenuCode.GDTextoNumeroTextObjects2.length = 0;
gdjs.MenuCode.GDTextInputNameObjects1.length = 0;
gdjs.MenuCode.GDTextInputNameObjects2.length = 0;
gdjs.MenuCode.GDButtonPlayObjects1.length = 0;
gdjs.MenuCode.GDButtonPlayObjects2.length = 0;

gdjs.MenuCode.eventsList0(runtimeScene);
return;

}

gdjs['MenuCode'] = gdjs.MenuCode;
