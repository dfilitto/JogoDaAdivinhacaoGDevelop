gdjs.GameOverCode = {};
gdjs.GameOverCode.GDCuteGirlObjects1= [];
gdjs.GameOverCode.GDCuteGirlObjects2= [];
gdjs.GameOverCode.GDCuteGirlObjects3= [];
gdjs.GameOverCode.GDBackgroundObjects1= [];
gdjs.GameOverCode.GDBackgroundObjects2= [];
gdjs.GameOverCode.GDBackgroundObjects3= [];
gdjs.GameOverCode.GDTextGameOverObjects1= [];
gdjs.GameOverCode.GDTextGameOverObjects2= [];
gdjs.GameOverCode.GDTextGameOverObjects3= [];
gdjs.GameOverCode.GDTextMsgObjects1= [];
gdjs.GameOverCode.GDTextMsgObjects2= [];
gdjs.GameOverCode.GDTextMsgObjects3= [];

gdjs.GameOverCode.conditionTrue_0 = {val:false};
gdjs.GameOverCode.condition0IsTrue_0 = {val:false};
gdjs.GameOverCode.condition1IsTrue_0 = {val:false};


gdjs.GameOverCode.asyncCallback7432684 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}
gdjs.GameOverCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(7), (runtimeScene) => (gdjs.GameOverCode.asyncCallback7432684(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameOverCode.eventsList1 = function(runtimeScene) {

{



}


{


gdjs.GameOverCode.condition0IsTrue_0.val = false;
{
gdjs.GameOverCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) > 0;
}if (gdjs.GameOverCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("CuteGirl"), gdjs.GameOverCode.GDCuteGirlObjects2);
gdjs.copyArray(runtimeScene.getObjects("TextGameOver"), gdjs.GameOverCode.GDTextGameOverObjects2);
gdjs.copyArray(runtimeScene.getObjects("TextMsg"), gdjs.GameOverCode.GDTextMsgObjects2);
{for(var i = 0, len = gdjs.GameOverCode.GDTextGameOverObjects2.length ;i < len;++i) {
    gdjs.GameOverCode.GDTextGameOverObjects2[i].setBBText("[outline=black][b]YOU WIN[/b] [/outline] ");
}
}{for(var i = 0, len = gdjs.GameOverCode.GDTextMsgObjects2.length ;i < len;++i) {
    gdjs.GameOverCode.GDTextMsgObjects2[i].setBBText("[outline=black][b]Nossa " + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) + ", você é incrível!!!!!! Jogue novamente para melhorar ainda mais o seu poder de dedução[/b] [/outline] ");
}
}{for(var i = 0, len = gdjs.GameOverCode.GDCuteGirlObjects2.length ;i < len;++i) {
    gdjs.GameOverCode.GDCuteGirlObjects2[i].setAnimation(3);
}
}}

}


{


gdjs.GameOverCode.condition0IsTrue_0.val = false;
{
gdjs.GameOverCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) <= 0;
}if (gdjs.GameOverCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("CuteGirl"), gdjs.GameOverCode.GDCuteGirlObjects2);
gdjs.copyArray(runtimeScene.getObjects("TextGameOver"), gdjs.GameOverCode.GDTextGameOverObjects2);
gdjs.copyArray(runtimeScene.getObjects("TextMsg"), gdjs.GameOverCode.GDTextMsgObjects2);
{for(var i = 0, len = gdjs.GameOverCode.GDTextGameOverObjects2.length ;i < len;++i) {
    gdjs.GameOverCode.GDTextGameOverObjects2[i].setBBText("[outline=black][b]GAME OVER[/b] [/outline] ");
}
}{for(var i = 0, len = gdjs.GameOverCode.GDTextMsgObjects2.length ;i < len;++i) {
    gdjs.GameOverCode.GDTextMsgObjects2[i].setBBText("[outline=black][b]Que pena  " + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) + ", você perdeu!!!!!! Jogue novamente para melhorar o seu poder de dedução[/b] [/outline] ");
}
}{for(var i = 0, len = gdjs.GameOverCode.GDCuteGirlObjects2.length ;i < len;++i) {
    gdjs.GameOverCode.GDCuteGirlObjects2[i].setAnimation(4);
}
}}

}


{


{

{ //Subevents
gdjs.GameOverCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.GameOverCode.eventsList2 = function(runtimeScene) {

{


gdjs.GameOverCode.condition0IsTrue_0.val = false;
{
gdjs.GameOverCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.GameOverCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameOverCode.eventsList1(runtimeScene);} //End of subevents
}

}


};

gdjs.GameOverCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GameOverCode.GDCuteGirlObjects1.length = 0;
gdjs.GameOverCode.GDCuteGirlObjects2.length = 0;
gdjs.GameOverCode.GDCuteGirlObjects3.length = 0;
gdjs.GameOverCode.GDBackgroundObjects1.length = 0;
gdjs.GameOverCode.GDBackgroundObjects2.length = 0;
gdjs.GameOverCode.GDBackgroundObjects3.length = 0;
gdjs.GameOverCode.GDTextGameOverObjects1.length = 0;
gdjs.GameOverCode.GDTextGameOverObjects2.length = 0;
gdjs.GameOverCode.GDTextGameOverObjects3.length = 0;
gdjs.GameOverCode.GDTextMsgObjects1.length = 0;
gdjs.GameOverCode.GDTextMsgObjects2.length = 0;
gdjs.GameOverCode.GDTextMsgObjects3.length = 0;

gdjs.GameOverCode.eventsList2(runtimeScene);
return;

}

gdjs['GameOverCode'] = gdjs.GameOverCode;
